# text-summarization
in this project we use text summarization in the paragraph
